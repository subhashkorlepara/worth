from flask import Flask,jsonify,request
from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
from flask_cors import CORS
import json
app=Flask("__name__")
CORS(app)
uri = "mongodb+srv://sairam12:6NNHvOqfqSDomZDz@cluster0.uaasc9e.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"

client = MongoClient(uri, server_api=ServerApi('1'))
try:
    client.admin.command('ping')
    print("Pinged your deployment. You successfully connected to MongoDB!")
    database = client["mydb"]
    collection = database["todolistitems"]
except Exception as e:
    print(e)

    
@app.route('/')
def index():
    return "Hello World"

@app.route('/addTodoItem',methods=['POST'])
def addTodoItem():
    if request.is_json:
        try:
            data=request.json
            collection.insert_one(data)
            return 'Success'
        except Exception as e:
            return 'Failed'
    else:
        return 'Failed'
@app.route('/updateStatus',methods=['POST'])
def updateStatus():
    if request.is_json:
        try:
            data=request.json
            print(data)
            query_filter = {'item_no' : int(data['item_no'])}
            update_operation = { '$set' : 
                { 'status' :  data['status']}
            }
            print(collection)
            result = collection.update_one(query_filter,update_operation)
            print(result)
            return 'Success'
        except Exception as e:
            print(e)
            return 'Failed'
    else:
        print('not a json')
        return 'Failed'
@app.route('/getTodoItems')
def displayName():
    try:
        results = collection.find({})
        sendResults = []
        for item in results:
            item.pop('_id')
            sendResults.append(item)
        print(sendResults)
        return jsonify(sendResults)
    except Exception as e:
        print(e)
        return 'Failed'
if __name__=="__main__":
    app.run(debug=True)